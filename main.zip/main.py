from process import *

process_date = date(year=2023, month=12, day=21)

generate_normative(process_date)
